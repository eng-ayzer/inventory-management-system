﻿namespace Inventory_Management_System
{
    partial class FrmProducReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.crvProductReports = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.SuspendLayout();
            // 
            // crvProductReports
            // 
            this.crvProductReports.ActiveViewIndex = -1;
            this.crvProductReports.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crvProductReports.Cursor = System.Windows.Forms.Cursors.Default;
            this.crvProductReports.DisplayStatusBar = false;
            this.crvProductReports.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crvProductReports.Location = new System.Drawing.Point(0, 0);
            this.crvProductReports.Name = "crvProductReports";
            this.crvProductReports.ShowCloseButton = false;
            this.crvProductReports.ShowCopyButton = false;
            this.crvProductReports.ShowGroupTreeButton = false;
            this.crvProductReports.ShowLogo = false;
            this.crvProductReports.Size = new System.Drawing.Size(1208, 747);
            this.crvProductReports.TabIndex = 0;
            this.crvProductReports.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            this.crvProductReports.Load += new System.EventHandler(this.crvProductReports_Load);
            // 
            // FrmProducReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1208, 747);
            this.Controls.Add(this.crvProductReports);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "FrmProducReports";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "FrmProducReports";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmProducReports_Load);
            this.ResumeLayout(false);

        }

        #endregion

        public CrystalDecisions.Windows.Forms.CrystalReportViewer crvProductReports;
    }
}