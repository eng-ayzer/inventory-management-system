﻿namespace Inventory_Management_System
{
    partial class FrmOrderReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CRVOrderReports = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.SuspendLayout();
            // 
            // CRVOrderReports
            // 
            this.CRVOrderReports.ActiveViewIndex = -1;
            this.CRVOrderReports.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CRVOrderReports.Cursor = System.Windows.Forms.Cursors.Default;
            this.CRVOrderReports.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CRVOrderReports.Location = new System.Drawing.Point(0, 0);
            this.CRVOrderReports.Name = "CRVOrderReports";
            this.CRVOrderReports.ShowCloseButton = false;
            this.CRVOrderReports.ShowCopyButton = false;
            this.CRVOrderReports.ShowGroupTreeButton = false;
            this.CRVOrderReports.ShowLogo = false;
            this.CRVOrderReports.Size = new System.Drawing.Size(1187, 708);
            this.CRVOrderReports.TabIndex = 0;
            this.CRVOrderReports.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            // 
            // FrmOrderReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1187, 708);
            this.Controls.Add(this.CRVOrderReports);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "FrmOrderReports";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "FrmOrderReports";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);

        }

        #endregion

        public CrystalDecisions.Windows.Forms.CrystalReportViewer CRVOrderReports;
    }
}