﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Inventory_Management_System
{
    public partial class FrmCategory : Form
    {
       
        public String CategoryID { get; set; }

        public FrmCategory()
        {
            InitializeComponent();
        }

        private void textSearch_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Category  Where CategoryName like '" + textSearch.Text + "%'", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvCategory.DataSource = dt;

            }
        }

        private void FrmCategory_Load(object sender, EventArgs e)
        {
            DisplayCategoryList();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (textCategory.Text == "" || textDescription.Text == "")
            {
                MessageBox.Show("Please fill the blank input field", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            using (SqlConnection conn = Form1.Connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "UspAddEditCategory";
                cmd.Parameters.AddWithValue("@id", "");
                cmd.Parameters.AddWithValue("@CategoryName", textCategory.Text);
                cmd.Parameters.AddWithValue("@Description", textDescription.Text);
                cmd.Parameters.AddWithValue("@type", "INSERT");
                cmd.ExecuteNonQuery();
                MessageBox.Show("New Category has been registred Thanks", "Add", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearTextBox();
                DisplayCategoryList();
                BtnAdd.Enabled = true;
                BtnUpdate.Enabled = false;
                BtnDelete.Enabled = false;
            }
        }

        private void DisplayCategoryList()
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Category", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvCategory.DataSource = dt;

            }
        }

        private void ClearTextBox()
        {
            textCategory.Clear();
            textDescription.Clear();
        }

        private void dgvCategory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvCategory_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            CategoryID = dgvCategory.CurrentRow.Cells[0].Value.ToString();
            textCategory.Text = dgvCategory.CurrentRow.Cells["CategoryName"].Value.ToString();
            textDescription.Text = dgvCategory.CurrentRow.Cells["Description"].Value.ToString();

            BtnAdd.Enabled = false;
            BtnUpdate.Enabled = true;
            BtnDelete.Enabled = true;
            



        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            if (textCategory.Text == "" || textDescription.Text == "")
            {
                MessageBox.Show("Please fill the blank input field", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = MessageBox.Show("Ma hubtaa inaad wax Badasho?", "Xaqiiji", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                using (SqlConnection conn = Form1.Connect())
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "UspAddEditCategory";
                    cmd.Parameters.AddWithValue("@id", CategoryID);
                    cmd.Parameters.AddWithValue("@CategoryName", textCategory.Text);
                    cmd.Parameters.AddWithValue("@Description", textDescription.Text);
                    cmd.Parameters.AddWithValue("@type", "UPDATE");
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Category Has been Updated Thanks", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearTextBox();
                    DisplayCategoryList();
                    BtnAdd.Enabled = false;
                    BtnUpdate.Enabled = true;
                    BtnDelete.Enabled = true;
                    

                }
            }
            else
            {
                // Haddii isticmaalaha uu doorto "No," waxba ha sameynin
                MessageBox.Show("Badalida waa la joojiyay.", "Joojin", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (textCategory.Text == "" || textDescription.Text == "")
            {
                MessageBox.Show("Please fill the blank input field", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = MessageBox.Show("Ma hubtaa inaad wax Tirto?", "Xaqiiji", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                using (SqlConnection conn = Form1.Connect())
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "UspAddEditCategory";
                    cmd.Parameters.AddWithValue("@id", CategoryID);
                    cmd.Parameters.AddWithValue("@CategoryName", textCategory.Text);
                    cmd.Parameters.AddWithValue("@Description", textDescription.Text);
                    cmd.Parameters.AddWithValue("@type", "DELETE");
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Category Has been Deleted Thanks", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    ClearTextBox();
                    DisplayCategoryList();
                    BtnAdd.Enabled = false;
                    BtnUpdate.Enabled = true;
                    BtnDelete.Enabled = true;

                    
                }
            }
            else
            {
                // Haddii isticmaalaha uu doorto "No," waxba ha sameynin
                MessageBox.Show("Tiridaada waa la joojiyay.", "Joojin", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textDescription_TextChanged(object sender, EventArgs e)
        {

        }

        private void textCategory_TextChanged(object sender, EventArgs e)
        {
            foreach (char c in textCategory.Text)
            {
                // Haddii xarafka uusan ahayn xaraf ama boos, khalad samee
                if (!char.IsLetter(c) && !char.IsWhiteSpace(c))
                {
                    MessageBox.Show("Kaliya Magaca xarfaha Ayaa la ogol yahay!.", "Khalad", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    // Ka saar xarafka khaldan
                    textCategory.Text = textCategory.Text.Remove(textCategory.Text.Length - 1);
                    textCategory.SelectionStart = textCategory.Text.Length; // Cursor-ka dib u dhig
                    break;
                }
            }
        }
    }
}
