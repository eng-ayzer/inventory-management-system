﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Inventory_Management_System
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {


            using (SqlConnection conn = Form1.Connect())
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM USERSES WHERE UserName = @UserName and Password = @Password", conn);
                cmd.Parameters.AddWithValue("@UserName", textUserName.Text);
                cmd.Parameters.AddWithValue("@Password", textPassword.Text);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    FrmMain frm = new FrmMain();
                    frm.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Username Or Password is incorrect ", "Error Login ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;

                }
            }
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {
            textPassword.PasswordChar = '*';
        }
    }
}
