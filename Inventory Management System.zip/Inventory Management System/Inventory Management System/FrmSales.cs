﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Inventory_Management_System
{
    public partial class FrmSales : Form
    {
        public FrmSales()
        {
            InitializeComponent();
        }

        public String ProductID { get; private set; }
        public int SelesID { get; private set; }

        private void cmbProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            ProductID = cmbProduct.SelectedValue.ToString();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (cmbProduct.Text == "Select Product Name" || txtQuantitySold.Text == "" || txtTotalAmount.Text == "")
            {
                MessageBox.Show("please fill the blank spac", "Eroor input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            GetLastOrderID();

            using (SqlConnection conn = Form1.Connect())
            {
                // Samee amar SQL
                SqlCommand cmd = new SqlCommand("INSERT INTO Seles (SelesID, QuantitySold, TotalAmount, ProductID) VALUES (@SelesID, @QuantitySold, @TotalAmount, @ProductID)", conn);

                // Ku dar parameters
                cmd.Parameters.AddWithValue("@SelesID", @SelesID);
                cmd.Parameters.AddWithValue("@QuantitySold", txtQuantitySold.Text.Trim());
                cmd.Parameters.AddWithValue("@TotalAmount", txtTotalAmount.Text.Trim());
                cmd.Parameters.AddWithValue("@ProductID", ProductID);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Seles Add successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearTextBox();
                DisplaySelesList();
            }
        }

        private void DisplaySelesList()
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT S.SelesID, S.QuantitySold, TotalAmount , P.ProductID, P.ProductName FROM Product P inner join Seles S on P.ProductID = S.ProductID ", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvSeles.DataSource = dt;
            }
        }

        private void ClearTextBox()
        {
            FillComboFaculty();
            txtQuantitySold.Clear();
            txtTotalAmount.Clear();
        }

        private void FillComboFaculty()
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT 0 AS ProductID, 'Select Product Name' AS ProductName UNION ALL SELECT  ProductID, ProductName FROM  Product", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                
                cmbProduct.ValueMember = "ProductID";
                cmbProduct.DisplayMember = "ProductName";

                cmbProduct.DataSource = dt;
            }
        }

        private void GetLastOrderID()
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlCommand cmd = new SqlCommand("SELECT TOP 1 SelesID FROM Seles order by 1 DESC", conn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    SelesID = (int)dr[0] + 1;

                }
                else
                {
                    SelesID = 100;
                }
            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Ma hubtaa inaad wax Badasho?", "Xaqiiji", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                using (SqlConnection conn = Form1.Connect())
                {
                    if (cmbProduct.Text == "Select Product Name" || txtQuantitySold.Text == "" || txtTotalAmount.Text == "")
                    {
                        MessageBox.Show("please fill the blank spac", "Eroor input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    SqlCommand cmd = new SqlCommand("UPDATE Seles SET QuantitySold = @QuantitySold , TotalAmount = @TotalAmount WHERE SelesID = @SelesID", conn);
                    cmd.Parameters.AddWithValue("@SelesID", SelesID);
                    cmd.Parameters.AddWithValue("@QuantitySold", txtQuantitySold.Text);
                    cmd.Parameters.AddWithValue("@TotalAmount", txtTotalAmount.Text);
                    //cmd.Parameters.AddWithValue("@CustomerID", CustomerID);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Seles has been UPDATE thanks", "UPDATE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearTextBox();
                    DisplaySelesList();
                    BtnAdd.Enabled = false;
                    BtnUpdate.Enabled = true;
                    BtnDelete.Enabled = true;

                }
            }
            else
            {
                // Haddii isticmaalaha uu doorto "No," waxba ha sameynin
                MessageBox.Show("Badalida waa la joojiyay.", "Joojin", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Ma hubtaa inaad wax Tirto?", "Xaqiiji", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                using (SqlConnection conn = Form1.Connect())
                {
                    if (cmbProduct.Text == "Select Product Name" || txtQuantitySold.Text == "" || txtTotalAmount.Text == "")
                    {
                        MessageBox.Show("please fill the blank spac", "Eroor input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    SqlCommand cmd = new SqlCommand("DELETE FROM Seles WHERE SelesID = @SelesID", conn);
                    cmd.Parameters.AddWithValue("@SelesID", SelesID);
                    cmd.Parameters.AddWithValue("@QuantitySold", txtQuantitySold.Text);
                    cmd.Parameters.AddWithValue("@TotalAmount", txtTotalAmount.Text);
                    //cmd.Parameters.AddWithValue("@CustomerID", CustomerID);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Seles has been DELETE thanks", "DELETE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearTextBox();
                    DisplaySelesList();
                    BtnAdd.Enabled = false;
                    BtnUpdate.Enabled = true;
                    BtnDelete.Enabled = true;

                }

            }
            else
            {
                // Haddii isticmaalaha uu doorto "No," waxba ha sameynin
                MessageBox.Show("Tirida waa la joojiyay.", "Joojin", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void textSearch_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Seles  Where SelesID like '" + textSearch.Text + "%'", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvSeles.DataSource = dt;

            }
        }

        private void dgvSales_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            SelesID = (int)dgvSeles.CurrentRow.Cells[0].Value;
            txtQuantitySold.Text = dgvSeles.CurrentRow.Cells["QuantitySold"].Value.ToString();
            txtTotalAmount.Text = dgvSeles.CurrentRow.Cells["TotalAmount"].Value.ToString();
            cmbProduct.Text = dgvSeles.CurrentRow.Cells["ProductName"].Value.ToString();
            BtnAdd.Enabled = false;
            BtnUpdate.Enabled = true;
            BtnDelete.Enabled = true;
        }

        private void FrmSales_Load(object sender, EventArgs e)
        {
            FillComboFaculty();
            DisplaySelesList();
            BtnAdd.Enabled = true;
            BtnUpdate.Enabled = false;
            BtnDelete.Enabled = false;
        }

        private void txtQuantitySold_TextChanged(object sender, EventArgs e)
        {
            foreach (char c in txtQuantitySold.Text)
            {
                // Haddii xarafka uu yahay mid aan lambar ahayn, samee khalad
                if (!char.IsDigit(c) && c != '.')
                {
                    MessageBox.Show("Kaliya lambaro ayaa la ogol yahay!.", "Khalad", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    // Ka saar xarafka khaldan
                    txtQuantitySold.Text = txtQuantitySold.Text.Remove(txtQuantitySold.Text.Length - 1);
                    txtQuantitySold.SelectionStart = txtQuantitySold.Text.Length; // Cursor-ka dhig dhammaadka
                    break;
                }
            }
        }

        private void txtTotalAmount_TextChanged(object sender, EventArgs e)
        {
            foreach (char c in txtTotalAmount.Text)
            {
                // Haddii xarafka uu yahay mid aan lambar ahayn, samee khalad
                if (!char.IsDigit(c) && c != '.' && c != '$')
                {
                    MessageBox.Show("Kaliya lambarrada ayaa la ogol yahay.", "Khalad", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    // Ka saar xarafka khaldan
                    txtTotalAmount.Text = txtTotalAmount.Text.Remove(txtTotalAmount.Text.Length - 1);
                    txtTotalAmount.SelectionStart = txtTotalAmount.Text.Length; // Cursor-ka dhig dhammaadka
                    break;
                }
            }
        }
    }
}
