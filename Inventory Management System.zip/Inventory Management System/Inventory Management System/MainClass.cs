﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory_Management_System
{
    class Form1
    {
        public static SqlConnection Connect()
        {
            SqlConnection conn = new SqlConnection(" Data Source = AWEIS\\SQLEXPRESS; initial Catalog = Inventory_Management_System; Integrated Security = True;");
            conn.Open();
            return conn;
        }

        
    }


}
