﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Inventory_Management_System
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
           
        }

        private void categoryToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
        }

        private void addEditUsersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmUserses frm = new FrmUserses(); 
            frm.Show();
            frm.MdiParent = this;
        }

        private void addCategoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            FrmCategory frm = new FrmCategory();
            frm.Show();
            frm.MdiParent = this;

        }

        private void addProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmProducts frm = new FrmProducts();
            frm.Show();
            frm.MdiParent = this;
        }

        private void addCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmCustomer  frm = new FrmCustomer();
            frm.Show();
            frm.MdiParent = this;
        }

        

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void projectNameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmProjectName frm = new FrmProjectName();
            frm.Show();
            frm.MdiParent = this;
        }

        private void customersToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void addCustomerToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FrmCustomer frm = new FrmCustomer();
            frm.Show();
            frm.MdiParent = this;
        }

        private void addOderToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FrmOrders frm = new FrmOrders();
            frm.Show();
            frm.MdiParent = this;
            
        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Weydii isticmaalaha haddii uu ka baxayo
            DialogResult result = MessageBox.Show(
                "Ma hubtaa inaad ka baxeyso?",
                "Ka Bax",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            // Haddii uu doorto "Yes"
            if (result == DialogResult.Yes)
            {
                // Dib ugu noqo foomka login
                FrmLogin loginForm = new FrmLogin();
                loginForm.Show();

                // Xir foomka hadda jira
                //Application.Exit();
            }
            // Haddii uu doorto "No", waxba ha sameynin
        }

        private void manageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void ordersToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmChangePassword frm = new FrmChangePassword();
            frm.Show();
            frm.MdiParent = this;
        }

        private void viewCategoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void reportsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmSales frm = new FrmSales();
            frm.Show();
            frm.MdiParent = this;
        }

        private void productReportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "CrptProductReportsWithCategory";

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                CrptProductReportsWithCategory cr = new CrptProductReportsWithCategory();
                cr.SetDataSource(dt);
                FrmProducReports frm = new FrmProducReports();
                frm.crvProductReports.ReportSource = cr;
                frm.Show();
            }
        }

        private void salesReportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "CrptSalesReportsWithProduct";

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                CrptSalesReportsWithProduct cr = new CrptSalesReportsWithProduct();
                cr.SetDataSource(dt);
                FrmSalesReports frm = new FrmSalesReports();
                frm.CrpSalesReports.ReportSource = cr;
                frm.Show();
            }
        }

        private void orderReportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "CrptOrderReportsWithCustomer";

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                CrptOrderReportsWithCustomer cr = new CrptOrderReportsWithCustomer();
                cr.SetDataSource(dt);
                FrmOrderReports frm = new FrmOrderReports();
                frm.CRVOrderReports.ReportSource = cr;
                frm.Show();
            }
        }
    }
}
