﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Inventory_Management_System
{
    public partial class FrmCustomer : Form
    {
        public int CustomerID { get; private set; }

        public FrmCustomer()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {

            // Hubi haddii meelaha qaar ay bannaan yihiin
            if (txtFirstName.Text == "" || txtLastName.Text == "" || txtEmail.Text == "" || txtPhone.Text == "" || txtCity.Text == "" || txtAddress.Text == "")
            {
                MessageBox.Show("Please fill in the blank spaces.", "Error input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Haddii meel bannaan ay jiraan, jooji hawsha
            }

            // Hubi saxnimada email-ka
            string email = txtEmail.Text;

            if (IsValidEmail(email))
            {
                // Haddii email-ka sax yahay, samee waxqabad (tusaale ahaan kaydi xogta)
                MessageBox.Show("Email-ku waa sax, xogtan waa la kaydinayaa.", "Sax!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Halkan waxaad ku dari kartaa koodhka kaydinta xogta
                // Tusaale ahaan: SaveData();
            }
            else
            {
                // Haddii email-ka qalad yahay, muuji fariin qalad ah
                MessageBox.Show("Fadlan gali email sax ah.", "Qalad!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEmail.Focus();
                return;
            }
        

            GetLastCustomerID();

            using (SqlConnection conn = Form1.Connect())
            {
                // Samee amar SQL
                SqlCommand cmd = new SqlCommand("INSERT INTO Customer (CustomerID, FirstName, LastName, Email, Phone, City, Address ) VALUES (@CustomerID,  @FirstName, @LastName, @Email, @Phone, @City, @Address )", conn);

                // Ku dar parameters
                cmd.Parameters.AddWithValue("@CustomerID", @CustomerID);
                cmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text.Trim());
                cmd.Parameters.AddWithValue("@LastName", txtLastName.Text.Trim());
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
                cmd.Parameters.AddWithValue("@Phone", txtPhone.Text.Trim());
                cmd.Parameters.AddWithValue("@City", txtCity.Text.Trim());
                cmd.Parameters.AddWithValue("@Address", txtAddress.Text.Trim());

                cmd.ExecuteNonQuery();
                MessageBox.Show("Customer Add successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearTextBox();
                DisplayCustomerList();
            }
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var mailAddress = new System.Net.Mail.MailAddress(email);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void DisplayCustomerList()
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT CustomerID, FirstName, LastName, Email, Phone, City, Address FROM Customer", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvCustomers.DataSource = dt;
            }
        }

        private void ClearTextBox()
        {
            txtFirstName.Clear();
            txtLastName.Clear();
            txtEmail.Clear();
            txtPhone.Clear();
            txtCity.Clear();
            txtAddress.Clear();
            
        }

        private void GetLastCustomerID()
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlCommand cmd = new SqlCommand("SELECT TOP 1 CustomerID FROM Customer order by 1 DESC", conn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    CustomerID = (int)dr[0] + 1;

                }
                else
                {
                    CustomerID = 100;
                }
            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Ma hubtaa inaad wax Badasho?", "Xaqiiji", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                using (SqlConnection conn = Form1.Connect())
                {
                    if (txtFirstName.Text == "" || txtLastName.Text == "" || txtEmail.Text == "" || txtPhone.Text == "" || txtCity.Text == "" || txtAddress.Text == "")
                    {
                        MessageBox.Show("please fill the blank spac", "Eroor input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    SqlCommand cmd = new SqlCommand("UPDATE Customer SET FirstName = @FirstName, LastName=@LastName, Email=@Email, Phone = @Phone, City = @City , Address = @Address where CustomerID = @CustomerID", conn);
                    cmd.Parameters.AddWithValue("@CustomerID", CustomerID);
                    cmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                    cmd.Parameters.AddWithValue("@LastName", txtLastName.Text);
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@Phone", txtPhone.Text);
                    cmd.Parameters.AddWithValue("@City", txtCity.Text);
                    cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
             
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer has been UPDATE thanks", "UPDATE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearTextBox();
                    DisplayCustomerList();
                    BtnAdd.Enabled = false;
                    BtnUpdate.Enabled = true;
                    BtnDelete.Enabled = true;

                }
            }
            else
            {
                // Haddii isticmaalaha uu doorto "No," waxba ha sameynin
                MessageBox.Show("Badalida waa la joojiyay.", "Joojin", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void dgvCustomers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            CustomerID = (int)dgvCustomers.CurrentRow.Cells[0].Value;
            txtFirstName.Text = dgvCustomers.CurrentRow.Cells["FirstName"].Value.ToString();
            txtLastName.Text = dgvCustomers.CurrentRow.Cells["LastName"].Value.ToString();
            txtEmail.Text = dgvCustomers.CurrentRow.Cells["Email"].Value.ToString();
            txtPhone.Text = dgvCustomers.CurrentRow.Cells["Phone"].Value.ToString();
            txtCity.Text = dgvCustomers.CurrentRow.Cells["City"].Value.ToString();
            txtAddress.Text = dgvCustomers.CurrentRow.Cells["Address"].Value.ToString();

            BtnAdd.Enabled = false;
            BtnUpdate.Enabled = true;
            BtnDelete.Enabled = true;
        }

        private void FrmCustomer_Load(object sender, EventArgs e)
        {
            
            DisplayCustomerList();
            BtnAdd.Enabled = true;
            BtnUpdate.Enabled = false;
            BtnDelete.Enabled = false;
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Ma hubtaa inaad wax Tirto?", "Xaqiiji", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                using (SqlConnection conn = Form1.Connect())
                {
                    if (txtFirstName.Text == "" || txtLastName.Text == "" || txtEmail.Text == "" || txtPhone.Text == "" || txtCity.Text == "" || txtAddress.Text == "")
                    {
                        MessageBox.Show("please fill the blank spac", "Eroor input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    SqlCommand cmd = new SqlCommand("DELETE FROM Customer WHERE CustomerID = @CustomerID", conn);
                    cmd.Parameters.AddWithValue("@CustomerID", CustomerID);
                    cmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                    cmd.Parameters.AddWithValue("@LastName", txtLastName.Text);
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@Phone", txtPhone.Text);
                    cmd.Parameters.AddWithValue("@City", txtCity.Text);
                    cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer has been DELETE thanks", "DELETE", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    ClearTextBox();
                    DisplayCustomerList();
                    BtnAdd.Enabled = false;
                    BtnUpdate.Enabled = true;
                    BtnDelete.Enabled = true;

                }
            }
            else
            {
                // Haddii isticmaalaha uu doorto "No," waxba ha sameynin
                MessageBox.Show("Tirida waa la joojiyay.", "Joojin", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void textSearch_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Customer  Where CustomerName like '" + textSearch.Text + "%'", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvCustomers.DataSource = dt;

            }
        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {
            foreach (char c in txtFirstName.Text)
            {
                if (!char.IsLetter(c) && !char.IsWhiteSpace(c))
                {
                    MessageBox.Show("Magaca waa inuu ka kooban yahay xarfo kaliya.", "Khalad", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtFirstName.Text = txtFirstName.Text.Remove(txtFirstName.Text.Length - 1);
                    txtFirstName.SelectionStart = txtFirstName.Text.Length;
                    break;
                }
            }
        }

        private void txtLastName_TextChanged(object sender, EventArgs e)
        {
            foreach (char c in txtLastName.Text)
            {
                if (!char.IsLetter(c) && !char.IsWhiteSpace(c))
                {
                    MessageBox.Show("Magaca dambe waa inuu ka kooban yahay xarfo kaliya.", "Khalad", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtLastName.Text = txtLastName.Text.Remove(txtLastName.Text.Length - 1);
                    txtLastName.SelectionStart = txtLastName.Text.Length;
                    break;
                }
            }
        }

        private void txtPhone_TextChanged(object sender, EventArgs e)
        {
            foreach (char c in txtPhone.Text)
            {
                if (!char.IsDigit(c))
                {
                    MessageBox.Show("Lambarka telefoonku waa inuu ka kooban yahay lambar kaliya.", "Khalad", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtPhone.Text = txtPhone.Text.Remove(txtPhone.Text.Length - 1);
                    txtPhone.SelectionStart = txtPhone.Text.Length;
                    break;
                }
            }
        }

        private void txtCity_TextChanged(object sender, EventArgs e)
        {
            foreach (char c in txtCity.Text)
            {
                if (!char.IsLetter(c) && !char.IsWhiteSpace(c))
                {
                    MessageBox.Show("Magaca magaalada waa inuu ka kooban yahay xarfo kaliya.", "Khalad", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtCity.Text = txtCity.Text.Remove(txtCity.Text.Length - 1);
                    txtCity.SelectionStart = txtCity.Text.Length;
                    break;
                }
            }
        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {
            foreach (char c in txtAddress.Text)
            {
                if (!char.IsLetterOrDigit(c) && !char.IsWhiteSpace(c))
                {
                    MessageBox.Show("Cinwaanka waa inuu ahaadaa xarfo ama lambar sax ah.", "Khalad", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtAddress.Text = txtAddress.Text.Remove(txtAddress.Text.Length - 1);
                    txtAddress.SelectionStart = txtAddress.Text.Length;
                    break;
                }
            }
        }
    }
}
