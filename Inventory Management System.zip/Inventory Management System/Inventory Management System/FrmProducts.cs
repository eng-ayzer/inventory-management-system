﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Inventory_Management_System
{
    public partial class FrmProducts : Form
    {
        public String CategoryID { get; private set; }
        public int ProductID { get; private set; }

        public FrmProducts()
        {
            InitializeComponent();
        }

        private void cmbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            CategoryID = cmbCategory.SelectedValue.ToString();
        }

        private void FrmProducts_Load(object sender, EventArgs e)
        {
            FillComboFaculty();
            DisplayProductList();
            BtnAdd.Enabled = true;
            BtnUpdate.Enabled = false;
            BtnDelete.Enabled = false;
        }

        private void FillComboFaculty()
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT 0 as CategoryID,'Select Category' as CategoryName UNION ALL SELECT CategoryID, CategoryName FROM Category", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                cmbCategory.ValueMember = "CategoryID";
                cmbCategory.DisplayMember = "CategoryName";
                cmbCategory.DataSource = dt;
            }
        }

        private void DisplayProductList()
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT P.ProductID, P.ProductName, P.QuantityInStock, P.Price, C.CategoryID, C.CategoryName FROM Category C inner join Product P on C.CategoryID = P.CategoryID", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvProductList.DataSource = dt;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (cmbCategory.Text == "Select Category" || txtProductName.Text == "" || txtQuantityInStock.Text == "" || txtPrice.Text == "")
            {
                MessageBox.Show("please fill the blank spac", "Eroor input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            GetLastProductID();

            using (SqlConnection conn = Form1.Connect())
            {
                // Samee amar SQL
                SqlCommand cmd = new SqlCommand("INSERT INTO Product (ProductID, ProductName, QuantityInStock, Price, CategoryID) VALUES (@ProductID, @ProductName, @QuantityInStock, @Price, @CategoryID)", conn);

                // Ku dar parameters
                cmd.Parameters.AddWithValue("@ProductID", @ProductID);
                cmd.Parameters.AddWithValue("@ProductName", txtProductName.Text.Trim());
                cmd.Parameters.AddWithValue("@QuantityInStock", txtQuantityInStock.Text.Trim());
                cmd.Parameters.AddWithValue("@Price", txtPrice.Text.Trim());
                cmd.Parameters.AddWithValue("@CategoryID", CategoryID);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Product Add successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearTextBox();
                DisplayProductList();
            }
        }

        private void ClearTextBox()
        {
            txtProductName.Clear();
            txtQuantityInStock.Clear();
            txtPrice.Clear();
            FillComboFaculty();
        }

        private void GetLastProductID()
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlCommand cmd = new SqlCommand("SELECT TOP 1 ProductID FROM Product order by 1 DESC", conn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    ProductID = (int)dr[0] + 1;

                }
                else
                {
                    ProductID = 100;
                }
            }
        }

        private void dgvProductList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            ProductID = (int)dgvProductList.CurrentRow.Cells[0].Value;
            txtProductName.Text = dgvProductList.CurrentRow.Cells["ProductName"].Value.ToString();
            txtQuantityInStock.Text = dgvProductList.CurrentRow.Cells["QuantityInStock"].Value.ToString();
            txtPrice.Text = dgvProductList.CurrentRow.Cells["Price"].Value.ToString();
            cmbCategory.SelectedValue = dgvProductList.CurrentRow.Cells["CategoryID"].Value.ToString();
            cmbCategory.Text = dgvProductList.CurrentRow.Cells["CategoryName"].Value.ToString();
            BtnAdd.Enabled = false;
            BtnUpdate.Enabled = true;
            BtnDelete.Enabled = true;
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Ma hubtaa inaad wax Tirto?", "Xaqiiji", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                using (SqlConnection conn = Form1.Connect())
                {
                    if (cmbCategory.Text == "Select Faculty" || txtProductName.Text == "" || txtQuantityInStock.Text == "" || txtPrice.Text == "")
                    {
                        MessageBox.Show("please fill the blank spac", "Eroor input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    SqlCommand cmd = new SqlCommand("DELETE FROM Product WHERE ProductID = @ProductID", conn);
                    cmd.Parameters.AddWithValue("@ProductID", ProductID);
                    cmd.Parameters.AddWithValue("@ProductName", txtProductName.Text);
                    cmd.Parameters.AddWithValue("@QuantityInStock", txtQuantityInStock.Text);
                    cmd.Parameters.AddWithValue("@Price", txtPrice.Text);
                    cmd.Parameters.AddWithValue("@CategoryID", CategoryID);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Product has been DELETE thanks", "DELETE", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    ClearTextBox();
                    DisplayProductList();
                    BtnAdd.Enabled = false;
                    BtnUpdate.Enabled = true;
                    BtnDelete.Enabled = true;

                }
            }
            else
            {
                // Haddii isticmaalaha uu doorto "No," waxba ha sameynin
                MessageBox.Show("Tirida waa la joojiyay.", "Joojin", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {

            DialogResult result = MessageBox.Show("Ma hubtaa inaad wax Badasho?", "Xaqiiji", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                using (SqlConnection conn = Form1.Connect())
            {
                if (cmbCategory.Text == "Select Faculty" || txtProductName.Text == "" || txtQuantityInStock.Text == "" || txtPrice.Text == "")
                {
                    MessageBox.Show("please fill the blank spac", "Eroor input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                SqlCommand cmd = new SqlCommand("UPDATE Product SET ProductName=@ProductName, QuantityInStock=@QuantityInStock, Price=@Price, CategoryID = @CategoryID where ProductID = @ProductID", conn);
                cmd.Parameters.AddWithValue("@ProductID", ProductID);
                cmd.Parameters.AddWithValue("@ProductName", txtProductName.Text);
                cmd.Parameters.AddWithValue("@QuantityInStock", txtQuantityInStock.Text);
                cmd.Parameters.AddWithValue("@Price", txtPrice.Text);
                cmd.Parameters.AddWithValue("@CategoryID", CategoryID);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Product has been UPDATE thanks", "UPDATE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearTextBox();
                DisplayProductList();
                BtnAdd.Enabled = false;
                BtnUpdate.Enabled = true;
                BtnDelete.Enabled = true;

            }
            }
            else
            {
                // Haddii isticmaalaha uu doorto "No," waxba ha sameynin
                MessageBox.Show("Badalida waa la joojiyay.", "Joojin", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void textSearch_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Product  Where ProductName like '" + textSearch.Text + "%'", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvProductList.DataSource = dt;

            }
        }

        private void txtProductName_TextChanged(object sender, EventArgs e)
        {
            foreach (char c in txtProductName.Text)
            {
                // Haddii xarafka uusan ahayn xaraf ama boos, khalad samee
                if (!char.IsLetter(c) && c != '\'' && !char.IsDigit(c) && !char.IsWhiteSpace(c))
                {
                    MessageBox.Show("Kaliya Magaca xarfaha Ayaa la ogol yahay!.", "Khalad", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    // Ka saar xarafka khaldan
                    txtProductName.Text = txtProductName.Text.Remove(txtProductName.Text.Length - 1);
                    txtProductName.SelectionStart = txtProductName.Text.Length; // Cursor-ka dib u dhig
                    break;
                }
            }
        }

        private void txtQuantityInStock_TextChanged(object sender, EventArgs e)
        {
            foreach (char c in txtQuantityInStock.Text)
            {
                // Haddii xarafka uu yahay mid aan lambar ahayn, samee khalad
                if (!char.IsDigit(c) && c != '.')
                {
                    MessageBox.Show("Kaliya lambaro ayaa la ogol yahay!.", "Khalad", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    // Ka saar xarafka khaldan
                    txtQuantityInStock.Text = txtQuantityInStock.Text.Remove(txtQuantityInStock.Text.Length - 1);
                    txtQuantityInStock.SelectionStart = txtQuantityInStock.Text.Length; // Cursor-ka dhig dhammaadka
                    break;
                }
            }
        }

        private void txtPrice_TextChanged(object sender, EventArgs e)
        {
            foreach (char c in txtPrice.Text)
            {
                // Haddii xarafka uu yahay mid aan lambar ahayn, samee khalad
                if (!char.IsDigit(c) && c != '.' && c != '$')
                {
                    MessageBox.Show("Kaliya lambarrada ayaa la ogol yahay.", "Khalad", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    // Ka saar xarafka khaldan
                    txtPrice.Text = txtPrice.Text.Remove(txtPrice.Text.Length - 1);
                    txtPrice.SelectionStart = txtPrice.Text.Length; // Cursor-ka dhig dhammaadka
                    break;
                }
            }
        }
    }
}
