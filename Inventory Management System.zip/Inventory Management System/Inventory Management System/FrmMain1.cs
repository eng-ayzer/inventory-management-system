﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory_Management_System
{
    class FrmMain1
    {
        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}
