﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Inventory_Management_System
{
    public partial class FrmChangePassword : Form
    {
        public string currentUserID { get; set; }
        public object UserID { get; private set; }

        public FrmChangePassword()
        {
            InitializeComponent();
        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {

           




        }

        private void FrmChangePassword_Load(object sender, EventArgs e)
        {

        }

        private void FrmChangePassword_Load_1(object sender, EventArgs e)
        {

        }

        private void btnChangePassword_Click_1(object sender, EventArgs e)
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlCommand cmd = new SqlCommand("UPDATE USERSES SET Password = @NewPassword where UserID = @UserID", conn);
                cmd.Parameters.AddWithValue("@UserID", UserID);
                cmd.Parameters.AddWithValue("@NewPassword", txtNewPassword.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Product has been UPDATE thanks", "UPDATE", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }
    }
}
