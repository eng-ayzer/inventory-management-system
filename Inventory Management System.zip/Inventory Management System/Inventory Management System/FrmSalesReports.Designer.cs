﻿namespace Inventory_Management_System
{
    partial class FrmSalesReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CrpSalesReports = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.SuspendLayout();
            // 
            // CrpSalesReports
            // 
            this.CrpSalesReports.ActiveViewIndex = -1;
            this.CrpSalesReports.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CrpSalesReports.Cursor = System.Windows.Forms.Cursors.Default;
            this.CrpSalesReports.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CrpSalesReports.Location = new System.Drawing.Point(0, 0);
            this.CrpSalesReports.Name = "CrpSalesReports";
            this.CrpSalesReports.ShowCloseButton = false;
            this.CrpSalesReports.ShowCopyButton = false;
            this.CrpSalesReports.ShowGroupTreeButton = false;
            this.CrpSalesReports.ShowLogo = false;
            this.CrpSalesReports.Size = new System.Drawing.Size(847, 609);
            this.CrpSalesReports.TabIndex = 0;
            this.CrpSalesReports.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            this.CrpSalesReports.Load += new System.EventHandler(this.CrpSalesReports_Load);
            // 
            // FrmSalesReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(847, 609);
            this.Controls.Add(this.CrpSalesReports);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "FrmSalesReports";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "FrmSalesReports";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmSalesReports_Load);
            this.ResumeLayout(false);

        }

        #endregion

        public CrystalDecisions.Windows.Forms.CrystalReportViewer CrpSalesReports;
    }
}