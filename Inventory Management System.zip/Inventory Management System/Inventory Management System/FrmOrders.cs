﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Inventory_Management_System
{
    public partial class FrmOrders : Form
    {
        public String CustomerID { get; private set; }
        public int OrderID { get; private set; }

        public FrmOrders()
        {
            InitializeComponent();
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Ma hubtaa inaad wax Badasho?", "Xaqiiji", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                using (SqlConnection conn = Form1.Connect())
                {
                    if (cmbCustomer.Text == "Select Customer Name" || txtTotalAmount.Text == "")
                    {
                        MessageBox.Show("please fill the blank spac", "Eroor input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    SqlCommand cmd = new SqlCommand("UPDATE [Order] SET TotalAmount = @TotalAmount WHERE OrderID = @OrderID", conn);
                    cmd.Parameters.AddWithValue("@OrderID", OrderID);
                    cmd.Parameters.AddWithValue("@TotalAmount", txtTotalAmount.Text);
                    //cmd.Parameters.AddWithValue("@CustomerID", CustomerID);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Order has been UPDATE thanks", "UPDATE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearTextBox();
                    DisplayOrderList();
                    BtnAdd.Enabled = false;
                    BtnUpdate.Enabled = true;
                    BtnDelete.Enabled = true;

                }
            }
            else
            {
                // Haddii isticmaalaha uu doorto "No," waxba ha sameynin
                MessageBox.Show("Badalida waa la joojiyay.", "Joojin", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void FrmOrders_Load(object sender, EventArgs e)
        {
            FillComboFaculty();
            DisplayOrderList();
            BtnAdd.Enabled = true;
            BtnUpdate.Enabled = false;
            BtnDelete.Enabled = false;
        }

        private void cmbCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            CustomerID = cmbCustomer.SelectedValue.ToString();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (cmbCustomer.Text == "Select Customer Name" || txtTotalAmount.Text == "")
            {
                MessageBox.Show("please fill the blank spac", "Eroor input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            GetLastOrderID();

            using (SqlConnection conn = Form1.Connect())
            {
                // Samee amar SQL
                SqlCommand cmd = new SqlCommand("INSERT INTO [Order] (OrderID, TotalAmount, CustomerID) VALUES (@OrderID, @TotalAmount, @CustomerID)", conn);

                // Ku dar parameters
                cmd.Parameters.AddWithValue("@OrderID", @OrderID);
                cmd.Parameters.AddWithValue("@TotalAmount", txtTotalAmount.Text.Trim());
                cmd.Parameters.AddWithValue("@CustomerID", CustomerID);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Order Add successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearTextBox();
                DisplayOrderList();
            }
        }

        private void DisplayOrderList()
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT O.OrderID, O.OrderDate, TotalAmount , C.CustomerID, C.FirstName, C.LastName, C.Email  FROM Customer C inner join [Order] O on C.CustomerID = O.CustomerID ", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvOrders.DataSource = dt;
            }
        }

        private void ClearTextBox()
        {
            txtTotalAmount.Clear();
            FillComboFaculty();
        }

        private void FillComboFaculty()
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT 0 AS CustomerID, 'Select Customer Name' AS FirstName, '' AS LastName UNION ALL SELECT  CustomerID, FirstName, LastName FROM  Customer", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dt.Columns.Add("FullName", typeof(string), "FirstName + ' ' + LastName");

                cmbCustomer.ValueMember = "CustomerID";
                cmbCustomer.DisplayMember = "FullName";

                cmbCustomer.DataSource = dt;
            }
        }

        private void GetLastOrderID()
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlCommand cmd = new SqlCommand("SELECT TOP 1 OrderID FROM [Order] order by 1 DESC", conn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                   OrderID = (int)dr[0] + 1;

                }
                else
                {
                    OrderID = 100;
                }
            }
        }

        private void dgvOrders_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            OrderID = (int)dgvOrders.CurrentRow.Cells[0].Value;
            txtTotalAmount.Text = dgvOrders.CurrentRow.Cells["TotalAmount"].Value.ToString();
            cmbCustomer.Text = dgvOrders.CurrentRow.Cells["FirstName"].Value.ToString();
            BtnAdd.Enabled = false;
            BtnUpdate.Enabled = true;
            BtnDelete.Enabled = true;
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Ma hubtaa inaad wax Tirto?", "Xaqiiji", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                using (SqlConnection conn = Form1.Connect())
            {
                if (cmbCustomer.Text == "Select Customer Name" || txtTotalAmount.Text == "")
                {
                    MessageBox.Show("please fill the blank spac", "Eroor input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                SqlCommand cmd = new SqlCommand("DELETE FROM [Order] WHERE OrderID = @OrderID", conn);
                cmd.Parameters.AddWithValue("@OrderID", OrderID);
                cmd.Parameters.AddWithValue("@TotalAmount", txtTotalAmount.Text);
                //cmd.Parameters.AddWithValue("@CustomerID", CustomerID);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Order has been DELETE thanks", "DELETE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearTextBox();
                DisplayOrderList();
                BtnAdd.Enabled = false;
                BtnUpdate.Enabled = true;
                BtnDelete.Enabled = true;

            }

            }
            else
            {
                // Haddii isticmaalaha uu doorto "No," waxba ha sameynin
                MessageBox.Show("Tirida waa la joojiyay.", "Joojin", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void textSearch_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM [Order]  Where OrderID like '" + textSearch.Text + "%'", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvOrders.DataSource = dt;

            }
        }

        private void txtTotalAmount_TextChanged(object sender, EventArgs e)
        {
            foreach (char c in txtTotalAmount.Text)
            {
                // Haddii xarafka uu yahay mid aan lambar ahayn, samee khalad
                if (!char.IsDigit(c) && c != '.' && c != '$')
                {
                    MessageBox.Show("Kaliya lambarrada ayaa la ogol yahay.", "Khalad", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    // Ka saar xarafka khaldan
                    txtTotalAmount.Text = txtTotalAmount.Text.Remove(txtTotalAmount.Text.Length - 1);
                    txtTotalAmount.SelectionStart = txtTotalAmount.Text.Length; // Cursor-ka dhig dhammaadka
                    break;
                }
            }
        }
    }
}
