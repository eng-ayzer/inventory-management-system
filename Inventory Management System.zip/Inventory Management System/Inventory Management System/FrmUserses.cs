﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Inventory_Management_System
{
    public partial class FrmUserses : Form
    {
        public String UserID { get; set; }
        public FrmUserses()
        {
            InitializeComponent();
        }

        private void FrmUserses_Load(object sender, EventArgs e)
        {
            //FillComboUsers();
            DisplayUserList();
            BtnSave.Enabled = true;
            BtnUpdate.Enabled = false;
            BtnDelete.Enabled = false;
        }

     /*   private void FillComboUsers()
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT 0 as UserID,'Select User Type' as UserName UNION ALL SELECT UserID, UserName FROM USERSES", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                cboUserType.ValueMember = "UserID";
                cboUserType.DisplayMember = "UserName";
                cboUserType.DataSource = dt;
            }
        }
        */
        private void BtnSave_Click(object sender, EventArgs e)
        {

            if (textFirstName.Text == "" || textLastName.Text == "" || textUserName.Text == "" || textPassword.Text == "" || textConfirmPassword.Text == "" || cboUserType.Text == "")
            {
                MessageBox.Show("Please fill the blank input field", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else if (textPassword.Text != textConfirmPassword.Text)
            {
                MessageBox.Show("Password did not much", "Error Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //SaveData
            using (SqlConnection conn = Form1.Connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "UspAddEditUSERSES";
                cmd.Parameters.AddWithValue("@UserID", "");
                cmd.Parameters.AddWithValue("@FirstName", textFirstName.Text);
                cmd.Parameters.AddWithValue("@LastName", textLastName.Text);
                cmd.Parameters.AddWithValue("@UserName", textUserName.Text);
                cmd.Parameters.AddWithValue("@Password", textPassword.Text);
                cmd.Parameters.AddWithValue("@UserType", cboUserType.Text);
                cmd.Parameters.AddWithValue("@Type", "INSERT");
                cmd.ExecuteNonQuery();//DML
                MessageBox.Show("New User has been Registred Thanks", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
                ClearTextBox();
                DisplayUserList();
                BtnSave.Enabled = true;
                BtnUpdate.Enabled = false;
                BtnDelete.Enabled = false;
            }
        }

        private void ClearTextBox()
        {
            textFirstName.Clear();
            textLastName.Clear();
            textUserName.Clear();
            textPassword.Clear();
            textConfirmPassword.Clear();
            cboUserType.Text = "";
        }

        private void DisplayUserList()
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM USERSES", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvUSerList.DataSource = dt;

            }
        }

        private void dgvUSerList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
            
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            if (textFirstName.Text == "" || textLastName.Text == "" || textUserName.Text == "" || textPassword.Text == "" || textConfirmPassword.Text == "" || cboUserType.Text == "")
            {
                MessageBox.Show("Please fill the blank input field", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else if (textPassword.Text != textConfirmPassword.Text)
            {
                MessageBox.Show("Password did not much", "Error Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DialogResult result = MessageBox.Show("Ma hubtaa inaad wax Badasho?", "Xaqiiji", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                //Update Data
                using (SqlConnection conn = Form1.Connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "UspAddEditUSERSES";
                cmd.Parameters.AddWithValue("@UserID", UserID);
                cmd.Parameters.AddWithValue("@FirstName", textFirstName.Text);
                cmd.Parameters.AddWithValue("@LastName", textLastName.Text);
                cmd.Parameters.AddWithValue("@UserName", textUserName.Text);
                cmd.Parameters.AddWithValue("@Password", textPassword.Text);
                cmd.Parameters.AddWithValue("@UserType", cboUserType.Text);
                cmd.Parameters.AddWithValue("@Type", "UPDATE");
                cmd.ExecuteNonQuery();//DML
                MessageBox.Show("User has been Updated Thanks", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);

                ClearTextBox();
                DisplayUserList();
                BtnSave.Enabled = false;
                BtnUpdate.Enabled = true;
                BtnDelete.Enabled = true;
            }
            }
            else
            {
                // Haddii isticmaalaha uu doorto "No," waxba ha sameynin
                MessageBox.Show("Badilida waa la joojiyay.", "Joojin", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (textFirstName.Text == "" || textLastName.Text == "" || textUserName.Text == "" || textPassword.Text == "" || textConfirmPassword.Text == "" || cboUserType.Text == "")
            {
                MessageBox.Show("Please fill the blank input field", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else if (textPassword.Text != textConfirmPassword.Text)
            {
                MessageBox.Show("Password did not much", "Error Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DialogResult result = MessageBox.Show("Ma hubtaa inaad wax tirto?", "Xaqiiji", MessageBoxButtons.YesNo, MessageBoxIcon.Warning
            );

            if (result == DialogResult.Yes)
            {

                //Delete Data
                using (SqlConnection conn = Form1.Connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "UspAddEditUSERSES";
                cmd.Parameters.AddWithValue("@UserID", UserID);
                cmd.Parameters.AddWithValue("@FirstName", textFirstName.Text);
                cmd.Parameters.AddWithValue("@LastName", textLastName.Text);
                cmd.Parameters.AddWithValue("@UserName", textUserName.Text);
                cmd.Parameters.AddWithValue("@Password", textPassword.Text);
                cmd.Parameters.AddWithValue("@UserType", cboUserType.Text);
                cmd.Parameters.AddWithValue("@Type", "DELETE");
                cmd.ExecuteNonQuery();//DML
                MessageBox.Show("User has been Deleted Thanks", "DELETED", MessageBoxButtons.OK, MessageBoxIcon.Error);

                ClearTextBox();
                DisplayUserList();
                BtnSave.Enabled = false;
                BtnUpdate.Enabled = true;
                BtnDelete.Enabled = true;
            }
            }

            else
            {
                // Haddii isticmaalaha uu doorto "No," waxba ha sameynin
                MessageBox.Show("Tirtida waa la joojiyay.", "Joojin", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection conn = Form1.Connect())
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM USERSES  Where UserName like '" + textSearch.Text+"%'", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvUSerList.DataSource = dt;

            }
        }

        private void dgvUSerList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            UserID = dgvUSerList.CurrentRow.Cells[0].Value.ToString();
            textFirstName.Text = dgvUSerList.CurrentRow.Cells["FirstName"].Value.ToString();
            textLastName.Text = dgvUSerList.CurrentRow.Cells["LastName"].Value.ToString();
            textUserName.Text = dgvUSerList.CurrentRow.Cells["UserName"].Value.ToString();
            textPassword.Text = dgvUSerList.CurrentRow.Cells["Password"].Value.ToString();
            textConfirmPassword.Text = textPassword.Text;
            cboUserType.Text = dgvUSerList.CurrentRow.Cells["UserType"].Value.ToString();

            BtnSave.Enabled = false;
            BtnUpdate.Enabled = true;
            BtnDelete.Enabled = true;

            textUserName.ReadOnly = true;
            textPassword.ReadOnly = true;
            textConfirmPassword.ReadOnly = true;

            

        }

        private void dgvUSerList_Click(object sender, EventArgs e)
        {

        }

        private void textFirstName_TextChanged(object sender, EventArgs e)
        {
            foreach (char c in textFirstName.Text)
            {
                // Haddii xarafka uusan ahayn xaraf ama boos, khalad samee
                if (!char.IsLetter(c) && !char.IsWhiteSpace(c))
                {
                    MessageBox.Show("Kaliya Magaca xarfaha Ayaa la ogol yahay!.", "Khalad", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    // Ka saar xarafka khaldan
                    textFirstName.Text = textFirstName.Text.Remove(textFirstName.Text.Length - 1);
                    textFirstName.SelectionStart = textFirstName.Text.Length; // Cursor-ka dib u dhig
                    break;
                }
            }
        }

        private void textLastName_TextChanged(object sender, EventArgs e)
        {
            foreach (char c in textLastName.Text)
            {
                // Haddii xarafka uusan ahayn xaraf ama boos, khalad samee
                if (!char.IsLetter(c) && !char.IsWhiteSpace(c))
                {
                    MessageBox.Show("Kaliya Magaca xarfaha Ayaa la ogol yahay!.", "Khalad", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    // Ka saar xarafka khaldan
                    textLastName.Text = textLastName.Text.Remove(textLastName.Text.Length - 1);
                    textLastName.SelectionStart = textLastName.Text.Length; // Cursor-ka dib u dhig
                    break;
                }
            }
        }

        private void textUserName_TextChanged(object sender, EventArgs e)
        {
            foreach (char c in textUserName.Text)
            {
                // Haddii xarafka uusan ahayn xaraf ama boos, khalad samee
                if (!char.IsLetter(c) && !char.IsWhiteSpace(c))
                {
                    MessageBox.Show("Kaliya Magaca xarfaha Ayaa la ogol yahay!.", "Khalad", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    // Ka saar xarafka khaldan
                    textUserName.Text = textUserName.Text.Remove(textUserName.Text.Length - 1);
                    textUserName.SelectionStart = textUserName.Text.Length; // Cursor-ka dib u dhig
                    break;
                }
            }
        }

        private void cboUserType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //UserID = cboUserType.SelectedValue.ToString();
        }
    }
}
